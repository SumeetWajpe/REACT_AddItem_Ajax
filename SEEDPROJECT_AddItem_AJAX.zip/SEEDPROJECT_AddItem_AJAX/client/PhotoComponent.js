﻿import React from 'react';

export default class PhotoComponent extends  React.Component{
   
    constructor(props){
            super(props);
        this.state = { };
    }
    //componentDidMount(){
    //    var self = this;
    //    $.get('https://jsonplaceholder.typicode.com/photos/1',function(response){
    //        self.setState(response);
    //    });
    //}
    // OR ES 6
    componentDidMount(){       
        $.get(`https://jsonplaceholder.typicode.com/photos/${this.props.PhotoId}`,(response) => {
        this.setState(response);
    })
    }
  
render() {
    return    (<div>
                        <img src={this.state.url} height="100" width="100" />
                         {this.state.title}
                         <hr/>
                    </div>);
}
}