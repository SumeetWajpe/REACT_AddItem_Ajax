﻿import React from 'react';
import ReactDOM from 'react-dom';

export default class FormsComponent extends  React.Component{
   
    constructor(props){
            super(props);
            this.state = { courseName:'ReactJS' };
            this.onChangeHandler = this.onChangeHandler.bind(this);
            this.onClickHandler = this.onClickHandler.bind(this);

    }
    componentWillMount(){
        // set some default state
        console.log('Component Will Mount called !');
    }
    componentDidMount(){
        // make ajaxified request or any operation which uses DOM
        console.log('Component Did Mount called !');
    }
    shouldComponentUpdate(){
        // return true or false !
        console.log(arguments);
        console.log(this.state.courseName);
        console.log('should Component Update called !');
        if(arguments[1].length > 10){
            return false;
        }
        return true;
    }
    componentWillUpdate(){
        // fired when ShouldCommponent will return true
        console.log('Component Will Update called !');
    }
    componentDidUpdate(){       
        console.log('component Did Update called !');
        console.log(this.state.courseName);
    }
    onChangeHandler(event){
        // Handle Change here !
        this.setState({courseName : event.target.value })
    }
    onClickHandler(){
        this.setState({courseName : 
            ReactDOM.findDOMNode(this.refs.targetInput).value });
    }

    render() {
        console.log('Render called !');
        return    (
            <form>
                <label> Course Name :  </label>
         <input type="text" value={this.state.courseName} onChange={this.onChangeHandler} />
         <label>{this.state.courseName}</label>
            </form> 
            );
    }
    //render() {
    //    return    (
    //        <form>
    //            <label> Course Name :  </label>
    //    {/* <input type="text" value={this.state.courseName} onChange={this.onChangeHandler} /> */}
    //    <input type="text" ref="targetInput"  />  
    //    <input type="button" onClick={this.onClickHandler} value="Add Course" />
    //    <label>{this.state.courseName}</label>
    //        </form> 
    //        );
    //}
}