﻿import React from 'react';
import ReactDOM from 'react-dom';

//import {ButtonListComponent} from './ButtonList';

//import FormsComponent from './UsingForms';

//import PhotoComponent from './PhotoComponent';

import AlbumComponent from'./AlbumComponent';

ReactDOM.render(<AlbumComponent />, document.getElementById('content'));

