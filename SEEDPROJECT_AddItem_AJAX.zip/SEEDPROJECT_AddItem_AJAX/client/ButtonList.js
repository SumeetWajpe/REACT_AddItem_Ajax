﻿import React from 'react';
import ReactDOM from 'react-dom';
import {ButtonComponent} from './Button';

export class ButtonListComponent extends React.Component{
  
    constructor(){
        super();
        this.state = {
                buttonList:[10,20,30,50]
        }
    } 
    addItemHandler(){
        // access the value from text box !
        let txt = ReactDOM.findDOMNode(this.refs.txtValueFromUser);
        // set the state
        this.setState({buttonList: this.state.buttonList.concat(txt.value)});
    }
    render(){
        var buttonToBeCreated = this.state.buttonList.map((item,index) => {
            return <ButtonComponent InitialCount={item} key={index} />
            });
            return ( <div>             
                        <form className="form-inline">
                            <label htmlFor="txtEntry">Enter a number : </label>
                            <input type="text" ref="txtValueFromUser" className="form-control" id="txtEntry" />
                             <button type="button" onClick={this.addItemHandler.bind(this)} className="btn btn-success btn-sm">Add</button> <br/>
                             {buttonToBeCreated}
                        </form>
                    </div>                
                    );
    }
}  