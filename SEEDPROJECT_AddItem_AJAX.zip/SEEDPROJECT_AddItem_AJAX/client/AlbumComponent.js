﻿import React from 'react';
import ReactDOM from 'react-dom';

import PhotoComponent from './PhotoComponent';
import FormsComponent from './FormsComponent';

export default class AlbumComponent extends  React.Component{   
    constructor(props){
            super(props);
        this.onAddItem = this.onAddItem.bind(this);
        this.state = { photos:[1,2,3] };
    } 
    onAddItem(dataFromForm){        
        this.setState({photos:this.state.photos.concat(dataFromForm)}); // push is wrong practise !
    }
    render() { 
        var photosToBCreated = this.state.photos.map((item) => { 
            return <PhotoComponent PhotoId={item} key={Math.random() * this.state.photos.length } />
            });   

        return    (
            <div>
                <FormsComponent addItemOfAlbum={this.onAddItem} />
   
    {photosToBCreated}
    </div>        
        );
}
}