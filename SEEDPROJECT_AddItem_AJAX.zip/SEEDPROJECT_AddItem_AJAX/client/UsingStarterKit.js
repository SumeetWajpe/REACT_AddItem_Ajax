﻿import React from 'react';

export class UsingStarterKit extends React.Component {
    render() {
        return (     
              <h2>Welcome to React with ES 6 !</h2>
   );
    }
}