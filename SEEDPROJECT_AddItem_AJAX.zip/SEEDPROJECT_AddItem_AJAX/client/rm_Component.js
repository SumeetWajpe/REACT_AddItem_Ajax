﻿import React from 'react';
import ReactDOM from 'react-dom';

export default class FormsComponent extends  React.Component{   
    constructor(props){
            super(props);
            this.onAddItem = this.onAddItem.bind(this);
            this.state = { };
    } 
    onAddItem(){
        let txt =  ReactDOM.findDOMNode(this.refs.txtPhotoId).value; 
        this.props.addItemOfAlbum(txt);
    }
    render() {      
   
        return    (
            <div>
              <input type="text" ref="txtPhotoId" />
              <input type="button" onClick={this.onAddItem} value="Add" className="btn btn-success btn-sm" /> <br/>  
            </div>        
            );
    }
}

    