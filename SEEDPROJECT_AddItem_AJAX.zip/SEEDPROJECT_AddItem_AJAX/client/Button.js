﻿import React from 'react';

export class ButtonComponent extends  React.Component{
   
    constructor(props){
            super(props);
            this.state = { counter: +(this.props.InitialCount) };
    }

    incrementCount(){       
        this.setState({counter: this.state.counter+1});
    }
render() {
    return    (<button type="button" onClick={this.incrementCount.bind(this)} className="btn btn-primary btn-sm BtnMarginStyle">
                                  {this.state.counter}
                              </button>);
}
}